Font usage: Personal use only, no commercial use allowed
Distributed by: Font Monger


You may not edit this font
You may not rename this font
You may not repackage, distribute, or sale this font
You may not use this font in multimedia, tv, applications, video games, or film.


For a  font license visit:
http://www.fontmonger.com

